#!/bin/bash

#!/bin/bash
echo "enter 3 parameters: Date(like 0310), time(like 01:00:00), game(Blackjack, Roulette, or Texas)"
if [ $3 = 'Blackjack' ]; then
	echo "Blackjack DEALERS ON $1"
    grep $2 Dealer_Analysis/$1_Dealer_schedule|awk '{print $1 " " $2 ": " $3 " " $4}'> datinfo.txt
    cat datinfo.txt 
    echo -------------------------------------------------
elif [ $3 = 'Roulette' ]; then
	echo "Roulette DEALERS ON $1"
    grep $2 Dealer_Analysis/$1_Dealer_schedule|awk '{print $1 " " $2 ": " $5 " " $6}'> datinfo.txt
    cat datinfo.txt 
    echo -------------------------------------------------
elif [ $3 = 'Texas' ]; then
	echo "Texas-Hold-EM DEALERS ON $1"
    grep $2 Dealer_Analysis/$1_Dealer_schedule|awk '{print $1 " " $2 ": " $7 " " $8}'> datinfo.txt
    cat datinfo.txt 
    echo -------------------------------------------------
else
	echo "Sorry Error..... number: ID10T"
fi

