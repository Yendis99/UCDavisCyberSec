#!/bin/bash


echo "enter 2 parameters: Date(Like 0310),time(like 01:00:00)"
echo "DEALERS ON $1"
grep $2 Dealer_Analysis/$1_Dealer_schedule > datinfo.txt
cat datinfo.txt 
echo -------------------------------------------------
