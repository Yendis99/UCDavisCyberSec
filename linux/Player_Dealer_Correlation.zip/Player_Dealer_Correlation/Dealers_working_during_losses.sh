#!/bin/bash

echo
echo "PLAYERS On 0310"
echo "`grep - Player_Analysis/0310_win_loss_player_data`"
echo
echo "DEALERS ON 0310"
grep - Player_Analysis/0310_win_loss_player_data |grep  "`awk '{print $1 " " $2}'`" > dt1.txt Dealer_Analysis/0310_Dealer_schedule > dt1info.txt
cat dt1info.txt 
echo -------------------------------------------------

echo "PLAYERS On 0312"
echo "`grep - Player_Analysis/0312_win_loss_player_data`"
echo
echo "DEALERS ON 0310"
grep - Player_Analysis/0312_win_loss_player_data |grep  "`awk '{print $1 " " $2}'`" > dt2.txt Dealer_Analysis/0312_Dealer_schedule > dt2info.txt
cat dt2info.txt
echo -------------------------------------------------

echo "PLAERS On 0315"
echo "`grep - Player_Analysis/0315_win_loss_player_data`"
echo
echo "DEALERS ON 0315"
grep - Player_Analysis/0315_win_loss_player_data |grep  "`awk '{print $1 " " $2}'`" > dt3.txt Dealer_Analysis/0315_Dealer_schedule > dt3info.txt
cat dt3info.txt
echo -------------------------------------------------